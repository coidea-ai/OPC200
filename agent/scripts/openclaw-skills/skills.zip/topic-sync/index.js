#!/usr/bin/env node
/**
 * topic-sync - OPC200 课题同步 Skill
 * 
 * 功能：
 *   list                      列出所有可用课题
 *   pull <keyword>            根据编号或关键词查找并下载课题 + 安装辅助skill
 *   push <file> [topicName]   上传研究结果到OSS，自动命名
 * 
 * 命名规则: {groupId}小组+{topicName}+report.{ext}
 * 示例: 001小组+消费品行业近期的xxx问题+report.html
 * 
 * 用法：
 *   claw topic list
 *   claw topic pull 001
 *   claw topic pull 消费品
 *   claw topic push ./report.md              # 自动检测课题名
 *   claw topic push ./report.md "课题名称"    # 指定课题名
 *   claw topic upload ./report.md            # upload是push的别名
 */

const OSS = require('ali-oss');
const fs = require('fs');
const path = require('path');
const os = require('os');
const readline = require('readline');

// ============ 配置加载 ============
const CONFIG_PATH = path.join(__dirname, 'config.json');
let config;

try {
  config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
} catch (err) {
  console.error('❌ 配置文件读取失败，请检查 config.json');
  console.error(err.message);
  process.exit(1);
}

const SKILLS_DIR = config.install.skillsDir.replace(/^~/, os.homedir());
const TOPICS_DIR = path.join(SKILLS_DIR, '_topics');

// ============ OSS 客户端 ============
const client = new OSS({
  region: config.oss.region,
  bucket: config.oss.bucket,
  accessKeyId: config.oss.accessKeyId,
  accessKeySecret: config.oss.accessKeySecret,
  secure: config.oss.secure !== false,
});

// ============ 工具函数 ============

function expandHome(filepath) {
  return filepath.replace(/^~/, os.homedir());
}

function extractTopicNumber(topicName) {
  const match = topicName.match(/topic-?(\d+)/i);
  return match ? match[1] : '';
}

function extractTopicTitle(topicName) {
  // 去掉编号部分，保留标题
  return topicName.replace(/[【\[]topic-?\d+[】\]]\s*/, '').trim();
}

function findCurrentTopic() {
  // 尝试从当前工作目录推断课题
  const cwd = process.cwd();
  
  // 如果在 _topics/某个课题 下工作
  if (cwd.includes('_topics')) {
    const parts = cwd.split(path.sep);
    const topicIdx = parts.indexOf('_topics');
    if (topicIdx >= 0 && topicIdx + 1 < parts.length) {
      return parts[topicIdx + 1];
    }
  }
  
  // 检查当前目录下是否有 .topic 标记文件
  const topicMarker = path.join(cwd, '.topic');
  if (fs.existsSync(topicMarker)) {
    return fs.readFileSync(topicMarker, 'utf8').trim();
  }
  
  return null;
}

function generateReportName(filePath, topicName, groupId) {
  const ext = path.extname(filePath);
  const id = groupId || config.group.id || '001';
  const title = topicName ? extractTopicTitle(topicName) : '未命名课题';
  return `${id}小组+${title}+report${ext}`;
}

// ============ list ============

async function listTopics() {
  console.log('📋 正在获取课题列表...\n');
  
  try {
    const result = await client.list({
      prefix: config.paths.topicPrefix,
      delimiter: '/',
      'max-keys': 1000
    });
    
    const topics = [];
    
    if (result.prefixes) {
      for (const prefix of result.prefixes) {
        const dirName = prefix.replace(config.paths.topicPrefix, '').replace(/\/$/, '');
        if (dirName) topics.push(dirName);
      }
    }
    
    if (topics.length === 0) {
      console.log('暂无可用课题');
      return;
    }
    
    console.log(`找到 ${topics.length} 个课题：\n`);
    topics.forEach((topic, i) => {
      const num = extractTopicNumber(topic) || (i + 1);
      const title = extractTopicTitle(topic);
      console.log(`  [${num}] ${title}`);
      console.log(`      完整名称: ${topic}`);
    });
    console.log('\n使用 "claw topic pull <编号或关键词>" 下载课题');
    
  } catch (err) {
    console.error('❌ 获取课题列表失败:', err.message);
    process.exit(1);
  }
}

// ============ find topic ============

async function findTopic(keyword) {
  console.log(`🔍 搜索课题: "${keyword}"...\n`);
  
  try {
    const result = await client.list({
      prefix: config.paths.topicPrefix,
      delimiter: '/',
      'max-keys': 1000
    });
    
    const topics = [];
    if (result.prefixes) {
      for (const prefix of result.prefixes) {
        const dirName = prefix.replace(config.paths.topicPrefix, '').replace(/\/$/, '');
        if (dirName) topics.push({ name: dirName, prefix });
      }
    }
    
    const matched = topics.filter(t => {
      const lowerKeyword = keyword.toLowerCase();
      const lowerName = t.name.toLowerCase();
      if (lowerName.includes(lowerKeyword)) return true;
      // 支持用纯数字匹配编号
      const num = extractTopicNumber(t.name);
      if (num && lowerKeyword === num) return true;
      return false;
    });
    
    if (matched.length === 0) {
      console.log('❌ 未找到匹配的课题');
      console.log('\n可用课题：');
      topics.forEach((t, i) => console.log(`  ${i + 1}. ${t.name}`));
      return null;
    }
    
    if (matched.length > 1) {
      console.log(`找到 ${matched.length} 个匹配结果：\n`);
      matched.forEach((t, i) => console.log(`  ${i + 1}. ${t.name}`));
      console.log('\n请使用更精确的关键词');
      return null;
    }
    
    return matched[0];
    
  } catch (err) {
    console.error('❌ 搜索失败:', err.message);
    return null;
  }
}

// ============ pull ============

async function downloadTopic(topic) {
  console.log(`\n📥 下载课题: ${topic.name}`);
  
  const safeName = topic.name.replace(/[\\/:*?"<>|]/g, '_');
  const localDir = path.join(TOPICS_DIR, safeName);
  fs.mkdirSync(localDir, { recursive: true });
  
  try {
    const result = await client.list({
      prefix: topic.prefix,
      'max-keys': 1000
    });
    
    if (!result.objects || result.objects.length === 0) {
      console.log('  ⚠️ 课题目录为空');
      return { localDir, hasSkill: false };
    }
    
    let hasSkill = false;
    
    for (const obj of result.objects) {
      if (obj.name.endsWith('/')) continue;
      
      const relativePath = obj.name.replace(topic.prefix, '');
      const localPath = path.join(localDir, relativePath);
      
      fs.mkdirSync(path.dirname(localPath), { recursive: true });
      
      console.log(`  ⬇️  ${relativePath}`);
      await client.get(obj.name, localPath);
      
      if (relativePath.includes('skill/') || relativePath.includes('辅助skill/')) {
        hasSkill = true;
      }
    }
    
    // 写入.topic标记文件
    fs.writeFileSync(path.join(localDir, '.topic'), topic.name);
    
    console.log(`  ✅ 课题下载完成 → ${localDir}`);
    return { localDir, hasSkill, topicName: topic.name };
    
  } catch (err) {
    console.error('  ❌ 下载失败:', err.message);
    return null;
  }
}

async function installSkill(topic, topicLocalDir) {
  console.log(`\n🔧 检查辅助skill...`);
  
  const possibleSkillDirs = [
    path.join(topicLocalDir, 'skill'),
    path.join(topicLocalDir, '辅助skill'),
    path.join(topicLocalDir, '_skill'),
  ];
  
  let skillDir = null;
  for (const dir of possibleSkillDirs) {
    if (fs.existsSync(dir)) {
      skillDir = dir;
      break;
    }
  }
  
  if (!skillDir) {
    console.log('  ℹ️ 该课题暂无辅助skill');
    return;
  }
  
  const files = fs.readdirSync(skillDir);
  const skillFiles = files.filter(f => f.endsWith('.js') || f === 'SKILL.md');
  
  if (skillFiles.length === 0) {
    console.log('  ⚠️ skill目录为空');
    return;
  }
  
  const skillName = `${topic.name.replace(/[【】\[\]\\/:*?"<>|]/g, '')}_skill`;
  const targetDir = path.join(SKILLS_DIR, skillName);
  
  fs.mkdirSync(targetDir, { recursive: true });
  
  for (const file of files) {
    const src = path.join(skillDir, file);
    const dest = path.join(targetDir, file);
    if (fs.statSync(src).isDirectory()) continue;
    fs.copyFileSync(src, dest);
  }
  
  console.log(`  ✅ 辅助skill已安装 → ${targetDir}`);
  console.log(`  💡 使用方法: 查看 ${path.join(targetDir, 'SKILL.md')}`);
}

async function pullTopic(keyword) {
  const topic = await findTopic(keyword);
  if (!topic) return;
  
  console.log(`\n🎯 找到课题: ${topic.name}`);
  
  const result = await downloadTopic(topic);
  if (!result) return;
  
  await installSkill(topic, result.localDir);
  
  // 创建引导文件
  const guidePath = path.join(result.localDir, 'HOW_TO_SUBMIT.md');
  const guideContent = generateSubmitGuide(topic.name);
  fs.writeFileSync(guidePath, guideContent);
  
  console.log('\n✨ 课题准备完成！');
  console.log(`📁 课题位置: ${result.localDir}`);
  console.log('\n你可以开始研究了。完成后使用:');
  console.log(`  claw topic push <你的研究报告>`);
  console.log(`\n查看 ${guidePath} 了解详细提交方式`);
}

function generateSubmitGuide(topicName) {
  return `# 研究报告提交指南

## 命名规则
上传的报告将自动命名为：
\`\`\`
{小组编号}小组+{课题标题}+report.{扩展名}
\`\`\`

例如：\`001小组+消费品行业近期的xxx问题+report.html\`

## 提交方式

### 方式1：命令行
\`\`\`bash
# 在课题目录下执行（自动检测课题名）
claw topic push ./我的研究报告.md

# 或指定文件路径
claw topic push ~/桌面/研究报告.html

# 或指定课题名
claw topic push ./report.pdf "${topicName}"
\`\`\`

### 方式2：自然语言
直接输入：
- "帮我把报告上传到云端"
- "上传研究报告"
- "提交课题结果"

## 支持的格式
- Markdown (.md)
- HTML (.html)
- PDF (.pdf)
- Word (.docx)
- 其他任意格式

## 上传位置
报告将上传到 OSS 的 \`opc/report/\` 目录下。

---
课题名称: ${topicName}
`;
}

// ============ push / upload ============

async function askGroupId() {
  return new Promise(resolve => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
    rl.question('📝 请输入你的小组编号（如 001、002）: ', answer => {
      rl.close();
      const id = answer.trim();
      if (id) {
        config.group.id = id;
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2) + '\n');
        console.log(`✅ 小组编号已保存: ${id}`);
      }
      resolve(id || '001');
    });
  });
}

async function getGroupId() {
  if (config.group.id && config.group.id.trim()) {
    return config.group.id.trim();
  }
  console.log('\n⚠️  尚未设置小组编号');
  return await askGroupId();
}

async function pushReport(filePath, explicitTopicName) {
  const expandedPath = expandHome(filePath);
  
  if (!fs.existsSync(expandedPath)) {
    console.error(`❌ 文件不存在: ${expandedPath}`);
    process.exit(1);
  }
  
  // 确定课题名称
  let topicName = explicitTopicName;
  
  if (!topicName) {
    topicName = findCurrentTopic();
  }
  
  if (!topicName) {
    console.error('❌ 无法确定课题名称');
    console.error('请进入课题目录后执行，或指定课题名:');
    console.error('  claw topic push <文件> "课题名称"');
    process.exit(1);
  }
  
  // 检查/询问小组编号
  const groupId = await getGroupId();
  
  // 生成报告名称
  const reportName = generateReportName(expandedPath, topicName, groupId);
  const ossKey = `${config.paths.reportPrefix}${reportName}`;
  
  console.log(`\n📤 准备上传报告`);
  console.log(`   原始文件: ${path.basename(expandedPath)}`);
  console.log(`   课题名称: ${topicName}`);
  console.log(`   小组编号: ${groupId}`);
  console.log(`   生成名称: ${reportName}`);
  console.log(`   目标路径: ${ossKey}`);
  
  try {
    await client.put(ossKey, expandedPath);
    console.log('\n✅ 上传成功！');
    console.log(`   OSS路径: ${ossKey}`);
    console.log(`   访问地址: https://${config.oss.bucket}.${config.oss.region}.aliyuncs.com/${ossKey}`);
  } catch (err) {
    console.error('\n❌ 上传失败:', err.message);
    process.exit(1);
  }
}

// ============ 命令解析 ============
const args = process.argv.slice(2);
const command = args[0];

if (!command || command === 'list' || command === 'ls') {
  listTopics();
} else if (command === 'pull' || command === 'download') {
  const keyword = args[1];
  if (!keyword) {
    console.error('用法: claw topic pull <课题编号或关键词>');
    process.exit(1);
  }
  pullTopic(keyword);
} else if (command === 'push' || command === 'upload') {
  const filePath = args[1];
  const explicitTopic = args[2]; // 可选的课题名
  
  if (!filePath) {
    console.error('用法: claw topic push <文件路径> [课题名称]');
    process.exit(1);
  }
  pushReport(filePath, explicitTopic);
} else {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║                 topic-sync - OPC200 课题同步                  ║
╠══════════════════════════════════════════════════════════════╣
║  用法:                                                       ║
║    claw topic list                    列出所有可用课题       ║
║    claw topic pull <编号/关键词>       下载课题并安装辅助skill║
║    claw topic push <文件路径> [课题名]  上传研究报告          ║
║    claw topic upload <文件路径>        push 的别名          ║
╠══════════════════════════════════════════════════════════════╣
║  示例:                                                       ║
║    claw topic pull 001                                       ║
║    claw topic pull 消费品                                     ║
║    claw topic push ./report.md              # 自动检测课题   ║
║    claw topic push ./report.md "课题名称"    # 指定课题      ║
╠══════════════════════════════════════════════════════════════╣
║  自然语言触发:                                               ║
║    "帮我把报告上传到云端"                                    ║
║    "上传研究报告"                                            ║
║    "提交课题结果"                                            ║
╚══════════════════════════════════════════════════════════════╝
`);
  process.exit(1);
}
