# topic-sync Skill

OPC200 大会课题同步工具。用于从阿里云OSS拉取课题、安装辅助skill，以及上传研究报告。

## 功能

### 1. 列出课题
```
claw topic list
```

### 2. 下载课题
支持通过课题编号或关键词搜索：
```
claw topic pull 001              # 按编号
claw topic pull 消费品            # 按关键词
claw topic pull topic-001        # 完整编号
```

执行后会：
- 从OSS下载课题文档和资料
- 自动检测并安装课题配套的辅助skill
- 在课题目录生成 `HOW_TO_SUBMIT.md` 提交指南
- 保存到 `~/.openclaw/workspace/skills/_topics/`

### 3. 上传报告
```
# 在课题目录下执行（自动检测课题名）
claw topic push ./研究报告.md

# 或指定文件路径
claw topic push ~/桌面/结果.html

# 或指定课题名
claw topic push ./report.pdf "【topic-001】消费品行业..."
```

**自动命名规则**：
```
{小组编号}小组+{课题标题}+report.{扩展名}
```
示例：`001小组+消费品行业近期的xxx问题+report.html`

## 配置

编辑 `config.json`：

```json
{
  "oss": {
    "region": "oss-cn-beijing",
    "bucket": "your-bucket",
    "accessKeyId": "your-ak",
    "accessKeySecret": "your-sk"
  },
  "paths": {
    "topicPrefix": "opc200/topic/",
    "reportPrefix": "opc200/report/"
  },
  "group": {
    "id": "001",
    "name": ""
  }
}
```

### 小组配置
- `group.id`: 小组编号，用于报告命名（如 001, 002...）
- 每个安装实例可配置不同的小组编号

## OSS 目录约定

```
opc200/
├── topic/                          # 课题目录
│   ├── 【topic-001】消费品行业.../     # 课题文件夹
│   │   ├── 课题说明.md
│   │   ├── HOW_TO_SUBMIT.md        # 提交指南（自动生成）
│   │   └── skill/                  # 辅助skill（可选）
│   │       ├── index.js
│   │       └── SKILL.md
│   └── 【topic-002】.../
└── report/                         # 研究报告上传目录
    ├── 001小组+消费品行业...report.html
    └── 002小组+...report.pdf
```

## 自然语言触发

支持以下话术自动触发：
- "帮我把报告上传到云端"
- "上传研究报告"
- "提交课题结果"
- "帮我把结果传到服务器"

## 注意事项

- 需要外网访问阿里云OSS
- 依赖 Node.js 和 `ali-oss` 包（已预装）
- 辅助skill会安装到 `~/.openclaw/workspace/skills/` 下
- 报告上传时自动从当前目录检测课题名称
- 支持格式：md, html, pdf, docx, 等任意格式
